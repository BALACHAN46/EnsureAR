(function(global) {
    'use strict';
    global.EnsureAR = global.EnsureAR || {};
    global.EnsureAR.Eyewear = global.EnsureAR.Eyewear || {};

    // Note: Depends on DEPTH_SCALE (-200) typical in EnsureAR projects
    const DEPTH_SCALE = -200;

    global.EnsureAR.Eyewear.AnchorCalculator = class AnchorCalculator {
        constructor() {
            this.lastAnchor = null;
        }

        /**
         * Blends eye midpoint and nose bridge to find the perfect resting position.
         */
        compute(landmarks, isBlinking, w, h) {
            // Blink handling: keep previous anchor
            if (isBlinking && this.lastAnchor !== null) {
                return this.lastAnchor;
            }

            //const left = landmarks.leftEyeCenter;
            //const right = landmarks.rightEyeCenter;
            //const eyeMidpoint = {
            //    x: (left.x + right.x) * 0.5,
            //    y: (left.y + right.y) * 0.5,
            //    z: (left.z + right.z) * 0.5
            //};

            //const bridge = landmarks.noseBridge;


            //const left = landmarks.leftEyeCenter;
            //const right = landmarks.rightEyeCenter;
            //const left = landmarks.faceLeftEyeOuter;   // landmark 33
            //const right = landmarks.faceRightEyeOuter; // landmark 263
            //const bridge = landmarks.noseBridge;

            //const eyeMid = {
            //    x: (left.x + right.x) * 0.5,
            //    y: (left.y + right.y) * 0.5,
            //    z: (left.z + right.z) * 0.5
            //};


            // X comes mostly from eye midpoint for perfect horizontal centering
            //const anchorX = eyeMidpoint.x;

            const left = landmarks.faceLeftEyeOuter;
            const right = landmarks.faceRightEyeOuter;
            const bridge = landmarks.noseBridge;
            const eyeMid = {
                x: (left.x + right.x) * 0.5,
                y: (left.y + right.y) * 0.5,
                z: (left.z + right.z) * 0.5
            };

            // Blend with nose bridge
            const anchorX = eyeMid.x * 0.85 + bridge.x * 0.15;
            const anchorY = eyeMid.y * 0.65 + bridge.y * 0.35;
            const anchorZ = eyeMid.z * 0.60 + bridge.z * 0.40;
            //const anchorX = (left.x + right.x) * 0.5;
            //const anchorY = (left.y + right.y) * 0.5 + 0.012;
            //const anchorY = eyeMid.y;
            //const anchorZ = eyeMid.z - 0.02;
            // Y comes mostly from nose bridge where glasses actually rest
            //const anchorY = (eyeMidpoint.y * 0.2) + (bridge.y * 0.8);

            // Z comes from bridge with slight forward offset
            //const anchorZ = bridge.z + 0.035;

            // Map normalised coordinates to world space
            //const worldPos = new THREE.Vector3(
            //    (1 - anchorX - 0.5) * w,
            //    -(anchorY - 0.5) * h,
            //    anchorZ * DEPTH_SCALE
            //);
            const worldPos = new THREE.Vector3(
                (1 - anchorX - 0.5) * w,
                -(anchorY - 0.5) * h,
                anchorZ * DEPTH_SCALE
            );

            this.lastAnchor = worldPos;
            return worldPos;
        }
        
        reset() {
            this.lastAnchor = null;
        }
    };
})(window);
