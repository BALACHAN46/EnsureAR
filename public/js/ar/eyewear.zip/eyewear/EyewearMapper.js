(function(global) {
    'use strict';
    global.EnsureAR = global.EnsureAR || {};
    global.EnsureAR.Eyewear = global.EnsureAR.Eyewear || {};

    global.EnsureAR.Eyewear.EyewearMapper = class EyewearMapper {
        constructor() {
            this.eyeTracker = new global.EnsureAR.Eyewear.EyeTracker();
            this.poseEstimator = new global.EnsureAR.Eyewear.FacePoseEstimator();
            this.scaleEstimator = new global.EnsureAR.Eyewear.ScaleEstimator();
            this.anchorCalculator = new global.EnsureAR.Eyewear.AnchorCalculator();
            this.filter = new global.EnsureAR.Eyewear.LandmarkFilter();
        }

        /**
         * Computes the final Transform (position, rotation, scale) for the eyewear.
         * @returns {Object|null} { model: { position, quaternion, scale }, isBlinking, landmarks, rawAnchor, rawScale }
         */
        map(faceResult, modelMeta, w, h) {
            if (!THREE) return null;

            // 1. Extract specific landmarks & detect blinks
            const landmarks = this.eyeTracker.track(faceResult);
            if (!landmarks) return null;

            // 2. Compute base anchor (blending eyes and nose)
            const rawAnchor = this.anchorCalculator.compute(landmarks, landmarks.isBlinking, w, h);

            // 3. Estimate scale (IPD + face width)
            const rawScale = this.scaleEstimator.estimate(landmarks, w, h, landmarks.isBlinking);

            // 4. Estimate full head pose (quaternion)
            //const rawQuat = this.poseEstimator.getPose(faceResult);

            //// 5. Apply temporal smoothing (One-Euro)
            //// 5. Apply temporal smoothing (One-Euro)
            //const ts = performance.now();
            //const filtered = this.filter.filterTransform(rawAnchor, rawQuat, rawScale, ts);

            //// ----------------------------------------------------
            //// Default eyewear pitch correction
            //// Rotates glasses slightly downward
            //// ----------------------------------------------------
            //const DOWN_PITCH = THREE.MathUtils.degToRad(-8); // try -6 to -10

            //const pitchQuat = new THREE.Quaternion().setFromEuler(
            //    new THREE.Euler(DOWN_PITCH, 0, 0, 'XYZ')
            //);

            //// Apply after head tracking
            //filtered.quaternion.multiply(pitchQuat);
            //// 6. Apply admin overrides from modelMeta
            //const off = modelMeta?.offset ?? [0, 0, 0];

            //// Use world units instead of screen pixels
            //filtered.position.x += off[0];
            //filtered.position.y += off[1];
            //filtered.position.z += off[2];

            ////if (modelMeta?.rotationOffset) {
            ////    const ro = modelMeta.rotationOffset;
            ////    if (ro[0] || ro[1] || ro[2]) {
            ////        const extra = new THREE.Quaternion().setFromEuler(
            ////            new THREE.Euler(ro[0] * Math.PI / 180, ro[1] * Math.PI / 180, ro[2] * Math.PI / 180)
            ////        );
            ////        filtered.quaternion.multiply(extra);
            ////    }
            ////}
            //if (modelMeta?.rotationOffset) {

            //    const ro = modelMeta.rotationOffset;

            //    const adminQuat = new THREE.Quaternion().setFromEuler(
            //        new THREE.Euler(
            //            THREE.MathUtils.degToRad(ro[0]),
            //            THREE.MathUtils.degToRad(ro[1]),
            //            THREE.MathUtils.degToRad(ro[2]),
            //            'XYZ'
            //        )
            //    );

            //    filtered.quaternion.multiply(adminQuat);
            //}

            //const ms = modelMeta?.scale ?? [1, 1, 1];
            //filtered.scale = new THREE.Vector3(filtered.scale * ms[0], filtered.scale * ms[1], filtered.scale * ms[2]);
            // 4. Estimate head pose
            const rawQuat = this.poseEstimator.getPose(faceResult);

            // 5. Smooth transform
            const ts = performance.now();
            const filtered = this.filter.filterTransform(rawAnchor, rawQuat, rawScale, ts);

            // ----------------------------------------------------
            // Head pose compensation
            // ----------------------------------------------------
            const euler = new THREE.Euler().setFromQuaternion(filtered.quaternion, 'YXZ');

            const yaw = euler.y;
            const pitch = euler.x;

            // Distance between eyes
            const eyeDistance = Math.abs(
                landmarks.faceLeftEyeOuter.x -
                landmarks.faceRightEyeOuter.x
            );

            // ----------------------------------------------------
            // Position compensation while turning
            // ----------------------------------------------------

            // Keep bridge centered during yaw
            filtered.position.x += Math.sin(yaw) * eyeDistance * w * 0.10;

            // Push glasses slightly into the face while turning
            filtered.position.z += Math.abs(Math.sin(yaw)) * 2.5;

            // Small vertical correction while looking up/down
            filtered.position.y -= Math.sin(pitch) * 2.0;

            // ----------------------------------------------------
            // Scale compensation
            // ----------------------------------------------------
            const yawScale = 1.0 + Math.abs(Math.sin(yaw)) * 0.05;

            filtered.scale *= yawScale;
            // ----------------------------------------------------
            // Default downward pitch
            // ----------------------------------------------------
            const pitchQuat = new THREE.Quaternion().setFromEuler(
                new THREE.Euler(
                    THREE.MathUtils.degToRad(-8),
                    0,
                    0,
                    'XYZ'
                )
            );

            filtered.quaternion.multiply(pitchQuat);

            // ----------------------------------------------------
            // Model offset
            // ----------------------------------------------------
            const off = modelMeta?.offset ?? [0, 0, 0];

            filtered.position.x += off[0];
            filtered.position.y += off[1];
            filtered.position.z += off[2];

            // ----------------------------------------------------
            // Model rotation
            // ----------------------------------------------------
            if (modelMeta?.rotationOffset) {

                const ro = modelMeta.rotationOffset;

                const extra = new THREE.Quaternion().setFromEuler(
                    new THREE.Euler(
                        THREE.MathUtils.degToRad(ro[0]),
                        THREE.MathUtils.degToRad(ro[1]),
                        THREE.MathUtils.degToRad(ro[2]),
                        'XYZ'
                    )
                );

                filtered.quaternion.multiply(extra);
            }

            // ----------------------------------------------------
            // Model scale
            // ----------------------------------------------------
            const ms = modelMeta?.scale ?? [1, 1, 1];

            filtered.scale = new THREE.Vector3(
                filtered.scale * ms[0],
                filtered.scale * ms[1],
                filtered.scale * ms[2]
            );
            return {
                model: {
                    position: filtered.position,
                    quaternion: filtered.quaternion,
                    scale: filtered.scale
                },
                landmarks: landmarks,
                rawAnchor: rawAnchor,
                rawScale: rawScale,
                isBlinking: landmarks.isBlinking
            };
        }

        reset() {
            this.scaleEstimator.reset();
            this.anchorCalculator.reset();
            this.filter.reset();
        }
    };
})(window);
