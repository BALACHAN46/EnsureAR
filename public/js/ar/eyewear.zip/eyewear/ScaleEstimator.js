(function(global) {
    'use strict';
    global.EnsureAR = global.EnsureAR || {};
    global.EnsureAR.Eyewear = global.EnsureAR.Eyewear || {};

    global.EnsureAR.Eyewear.ScaleEstimator = class ScaleEstimator {
        constructor() {
            this.lastScale = null;
        }

        /**
         * Calculates a stable scale combining IPD and face width.
         */
        estimate(landmarks, w, h, isBlinking) {
            // Blink handling: prevent scale jumps during blinks
            if (isBlinking && this.lastScale !== null) {
                return this.lastScale;
            }

            const left = landmarks.leftEyeCenter;
            const right = landmarks.rightEyeCenter;
            const ipd = Math.hypot(left.x - right.x, left.y - right.y);

            const faceW = Math.hypot(landmarks.faceLeft.x - landmarks.faceRight.x, landmarks.faceLeft.y - landmarks.faceRight.y);

            // Standard glasses are ~1.5x IPD or 0.95x face width
            const ipdScale = ipd * w * 2.3;
            const faceScale = faceW * w * 1.05;

            // Blend them: 60% face width (very stable), 40% IPD
            const rawScale = (ipdScale * 0.4) + (faceScale * 0.6);

            this.lastScale = rawScale;
            return rawScale;
        }
        
        reset() {
            this.lastScale = null;
        }
    };
})(window);
